const $ = (s,root=document)=>root.querySelector(s);
const $$ = (s,root=document)=>[...root.querySelectorAll(s)];
const menu=$('#menuToggle'), nav=$('.main-nav');
menu.addEventListener('click',()=>nav.classList.toggle('open'));
$$('.main-nav a').forEach(a=>a.addEventListener('click',()=>nav.classList.remove('open')));
$('#searchToggle').addEventListener('click',()=>$('#searchStrip').classList.toggle('open'));
$('#searchGo').addEventListener('click',()=>{
 const q=$('#searchInput').value.trim().toLowerCase();
 $$('#collectionProducts .product-card').forEach(card=>card.hidden=!card.dataset.name.toLowerCase().includes(q));
});
$('#searchInput').addEventListener('keydown',e=>{if(e.key==='Enter')$('#searchGo').click()});

let cart=[];
const drawer=$('#cartDrawer'), overlay=$('#overlay');
function openCart(){drawer.classList.add('open');overlay.classList.add('show');drawer.setAttribute('aria-hidden','false')}
function closeCart(){drawer.classList.remove('open');overlay.classList.remove('show');drawer.setAttribute('aria-hidden','true')}
$('#cartOpen').addEventListener('click',openCart);$('#cartClose').addEventListener('click',closeCart);overlay.addEventListener('click',closeCart);
function renderCart(){
 $('#cartCount').textContent=cart.length;
 $('#cartItems').innerHTML=cart.length?cart.map((p,i)=>`<div class="cart-row"><span>${p.name}</span><b>${p.price.toLocaleString('en-US')} ج.م</b></div>`).join(''):'<p class="empty-cart">السلة فارغة حاليًا.</p>';
 $('#cartTotal').textContent=cart.reduce((s,p)=>s+p.price,0).toLocaleString('en-US')+' ج.م';
}
$$('.add-cart').forEach(btn=>btn.addEventListener('click',()=>{
 const card=btn.closest('.product-card');
 const name=$('h3',card).textContent;
 const priceText=$('strong',card)?.textContent||'0';
 const price=parseInt(priceText.replace(/[^\d]/g,''),10)||0;
 cart.push({name,price});renderCart();btn.textContent='تمت الإضافة ✓';setTimeout(()=>btn.textContent='أضف إلى السلة',1100);
}));
$$('.heart').forEach(b=>b.addEventListener('click',()=>{b.classList.toggle('liked');b.textContent=b.classList.contains('liked')?'♥':'♡'}));

$$('input[name="category"]').forEach(input=>input.addEventListener('change',()=>{
 const val=$('input[name="category"]:checked').value;
 let count=0;
 $$('#collectionProducts .product-card').forEach(card=>{const show=val==='all'||card.dataset.category===val;card.hidden=!show;if(show)count++});
 $('#resultCount').textContent=count;
}));
$('#clearFilters').addEventListener('click',()=>{const all=$('input[name="category"][value="all"]');all.checked=true;all.dispatchEvent(new Event('change'))});
$('#sortSelect').addEventListener('change',e=>{
 if(e.target.value==='name'){const grid=$('#collectionProducts');$$('.product-card',grid).sort((a,b)=>a.dataset.name.localeCompare(b.dataset.name)).forEach(c=>grid.append(c))}
});
$$('.faq-list details').forEach(d=>d.addEventListener('toggle',()=>{$('summary span',d).textContent=d.open?'−':'＋'}));

$('#fontPanelToggle').addEventListener('click',()=>$('#fontPanelBody').classList.toggle('open'));
$$('.font-choice').forEach(btn=>btn.addEventListener('click',()=>{
 document.body.classList.remove('font-naskh','font-amiri','font-ruqaa','font-kufi','font-plex');
 document.body.classList.add('font-'+btn.dataset.font);
 $$('.font-choice').forEach(b=>b.classList.toggle('selected',b===btn));
}));
$('#checkoutBtn').addEventListener('click',()=>alert('هذه معاينة تصميمية فقط. سيتم ربط الطلبات بنظام المتجر لاحقًا.'));


// Four-step perfume finder. Product matching is tag-driven: update data-tags on each product
// (or populate the same tags from the admin/API) and recommendations adapt automatically.
const quizQuestions=[
 {key:"audience",question:"لمن تبحث عن العطر؟",hint:"خلّينا نبدأ بالشخص اللي هيستخدم العطر.",options:[
  {label:"لرجال",icon:"♙",tag:"men"},{label:"للسيدات",icon:"♙",tag:"women"},{label:"هدية / مش فارقة",icon:"✧",tag:"unisex"}
 ]},
 {key:"occasion",question:"هتستخدمه إمتى؟",hint:"اختار الاستخدام الأقرب ليك.",options:[
  {label:"يومي وشغل",icon:"☼",tag:"daily"},{label:"خروجات وسهرات",icon:"☾",tag:"outing"},{label:"مناسبات",icon:"✦",tag:"occasion"}
 ]},
 {key:"family",question:"بتحب الريحة تبقى…",hint:"اختار عائلة الروائح اللي بتميل ليها.",options:[
  {label:"فريش ومنعشة",icon:"♢",tag:"fresh"},{label:"حلوة وفانيليا",icon:"❋",tag:"sweet"},{label:"خشبية وعود",icon:"♧",tag:"woody"},{label:"فواكه وورد",icon:"✿",tag:"floral"}
 ]},
 {key:"intensity",question:"عايزها تبقى…",hint:"قد إيه تحب حضور العطر يكون واضح؟",options:[
  {label:"هادية",icon:"◌",tag:"soft"},{label:"متوسطة",icon:"◐",tag:"moderate"},{label:"قوية وفواحة",icon:"✹",tag:"strong"}
 ]}
];
let quizStep=0,quizAnswers={};
const quizModal=document.getElementById("perfumeQuiz");
const quizOpeners=document.querySelectorAll(".quiz-start");
const quizCloseEls=quizModal.querySelectorAll("[data-quiz-close]");
const quizProgress=document.getElementById("quizProgress");
const quizStepLabel=document.getElementById("quizStep");
const quizQuestion=document.getElementById("quizQuestion");
const quizHint=document.getElementById("quizHint");
const quizOptions=document.getElementById("quizOptions");
const quizBack=document.getElementById("quizBack");
const quizNext=document.getElementById("quizNext");
const quizResults=document.getElementById("quizResults");
const quizContent=quizModal.querySelector(".quiz-content");

function openPerfumeQuiz(){
 quizStep=0;quizAnswers={};quizContent.hidden=false;quizResults.hidden=true;
 renderQuizStep();quizModal.classList.add("open");quizModal.setAttribute("aria-hidden","false");
 document.body.classList.add("quiz-open");quizModal.querySelector(".quiz-close").focus();
}
function closePerfumeQuiz(){
 quizModal.classList.remove("open");quizModal.setAttribute("aria-hidden","true");
 document.body.classList.remove("quiz-open");
}
quizOpeners.forEach(button=>button.addEventListener("click",openPerfumeQuiz));
quizCloseEls.forEach(el=>el.addEventListener("click",closePerfumeQuiz));
document.addEventListener("keydown",e=>{if(e.key==="Escape"&&quizModal.classList.contains("open"))closePerfumeQuiz()});

function renderQuizStep(){
 const q=quizQuestions[quizStep], selected=quizAnswers[q.key];
 quizStepLabel.textContent=`السؤال ${quizStep+1} من ${quizQuestions.length}`;
 quizQuestion.textContent=q.question;quizHint.textContent=q.hint;
 quizProgress.style.width=`${((quizStep+1)/quizQuestions.length)*100}%`;
 quizOptions.innerHTML=q.options.map(opt=>`
  <button type="button" class="quiz-option ${selected===opt.tag?"selected":""}" data-tag="${opt.tag}">
   <span class="quiz-option-icon">${opt.icon}</span><strong>${opt.label}</strong>
  </button>`).join("");
 quizOptions.querySelectorAll(".quiz-option").forEach(button=>button.addEventListener("click",()=>{
  quizAnswers[q.key]=button.dataset.tag;
  quizOptions.querySelectorAll(".quiz-option").forEach(b=>b.classList.toggle("selected",b===button));
  quizNext.disabled=false;
 }));
 quizBack.disabled=quizStep===0;
 quizNext.disabled=!selected;
 quizNext.innerHTML=quizStep===quizQuestions.length-1?'اعرض ترشيحاتي <span>←</span>':'التالي <span>←</span>';
}
quizBack.addEventListener("click",()=>{if(quizStep>0){quizStep--;renderQuizStep()}});
quizNext.addEventListener("click",()=>{
 if(!quizAnswers[quizQuestions[quizStep].key])return;
 if(quizStep<quizQuestions.length-1){quizStep++;renderQuizStep()}
 else showQuizRecommendations();
});

function showQuizRecommendations(){
 const allProducts=[...document.querySelectorAll("#collectionProducts .product-card")];
 const answers=Object.values(quizAnswers);
 const scored=allProducts.map(card=>{
  const tags=(card.dataset.tags||"").split(",").map(t=>t.trim()).filter(Boolean);
  const matches=answers.filter(tag=>tags.includes(tag)).length;
  return {card,tags,matches};
 }).filter(item=>item.matches>0).sort((a,b)=>b.matches-a.matches);
 const list=document.getElementById("recommendationList");
 const intro=document.getElementById("resultIntro");
 const best=scored.slice(0,3);
 if(!best.length){
  intro.textContent="لسه مفيش عطور متطابقة مع كل اختياراتك. تقدر تتصفح التشكيلة أو تغيّر إجاباتك.";
  list.innerHTML="";
 }else{
  intro.textContent="رشحنا لك العطور الأقرب لاختياراتك بناءً على خصائص كل عطر.";
  list.innerHTML=best.map(({card,matches})=>{
   const img=card.querySelector(".product-image img")?.getAttribute("src")||"";
   const name=card.querySelector(".product-info h3")?.textContent||card.dataset.name;
   const brand=card.querySelector(".product-brand")?.textContent||"AL AMIN";
   const price=card.querySelector(".price-line strong")?.textContent||"";
   return `<article class="recommendation-card"><img src="${img}" alt="${name}"><div class="recommendation-copy"><small>${brand}</small><strong>${name}</strong><span>متوافق مع ${matches} من 4 اختيارات</span><b>${price}</b></div></article>`;
  }).join("");
 }
 quizContent.hidden=true;quizResults.hidden=false;
 quizProgress.style.width="100%";
}
document.getElementById("quizRetake").addEventListener("click",()=>{quizStep=0;quizAnswers={};quizResults.hidden=true;quizContent.hidden=false;renderQuizStep()});
document.getElementById("quizBrowse").addEventListener("click",()=>{closePerfumeQuiz();document.getElementById("collection").scrollIntoView({behavior:"smooth"})});


// Al-Amin guided fragrance finder. Product recommendations are scored from product data-tags.
(() => {
  const overlay = document.getElementById('quizOverlay');
  if (!overlay) return;
  const content = document.getElementById('quizContent');
  const progress = document.getElementById('quizProgress');
  const stepLabel = document.getElementById('quizStepLabel');
  const next = document.getElementById('quizNext');
  const back = document.getElementById('quizBack');
  const questions = [
    { key:'audience', title:'العطر ده لمين؟', hint:'خلّينا نبدأ بالشخص اللي هيستخدم العطر', options:[
      {label:'لرجل',icon:'♙',value:'men'},
      {label:'لسيدة',icon:'♙',value:'women'},
      {label:'هدية / مش فارقة',icon:'✧',value:'any'}
    ]},
    { key:'occasion', title:'هتستخدمه إمتى؟', hint:'اختار الاستخدام الأقرب ليك', options:[
      {label:'يومي وشغل',icon:'☀',value:'daily'},
      {label:'خروجات وسهرات',icon:'☾',value:'outings'},
      {label:'مناسبات',icon:'✦',value:'formal'}
    ]},
    { key:'family', title:'بتحب الريحة تبقى…', hint:'اختار عائلة الروائح اللي بتميل لها', options:[
      {label:'فريش ومنعشة',icon:'🌊',value:'fresh'},
      {label:'حلوة وفانيليا',icon:'✿',value:'sweet'},
      {label:'خشبية وعود',icon:'♧',value:'woody'},
      {label:'فواكه وورد',icon:'❀',value:'floral'}
    ]},
    { key:'strength', title:'عايزها تبقى…', hint:'اختار قوة العطر المناسبة ليك', options:[
      {label:'هادية',icon:'◌',value:'calm'},
      {label:'متوسطة',icon:'✧',value:'medium'},
      {label:'قوية وفواحة',icon:'♨',value:'strong'}
    ]}
  ];
  let step = 0;
  let answers = {};
  let resultMode = false;

  function open() {
    step = 0; answers = {}; resultMode = false;
    next.style.display = '';
    overlay.classList.add('open');
    overlay.setAttribute('aria-hidden','false');
    document.body.style.overflow = 'hidden';
    render();
  }
  function close() {
    overlay.classList.remove('open');
    overlay.setAttribute('aria-hidden','true');
    document.body.style.overflow = '';
  }
  function render() {
    if (resultMode) { renderResults(); return; }
    const q = questions[step];
    progress.style.width = `${((step+1)/questions.length)*100}%`;
    stepLabel.textContent = `السؤال ${step+1} من ${questions.length}`;
    back.disabled = step === 0;
    next.disabled = !answers[q.key];
    next.innerHTML = step === questions.length-1 ? 'اعرض ترشيحاتي <span>←</span>' : 'التالي <span>←</span>';
    content.innerHTML = `
      <p class="quiz-kicker">السؤال ${step+1} من ${questions.length}</p>
      <h2 class="quiz-question">${q.title}</h2>
      <p class="quiz-hint">${q.hint}</p>
      <div class="quiz-options">${q.options.map(o=>`
        <button class="quiz-option ${answers[q.key]===o.value?'selected':''}" type="button" data-value="${o.value}">
          <span class="option-icon">${o.icon}</span><strong>${o.label}</strong>
        </button>`).join('')}
      </div>`;
    content.querySelectorAll('.quiz-option').forEach(btn=>btn.addEventListener('click',()=>{
      answers[q.key] = btn.dataset.value;
      content.querySelectorAll('.quiz-option').forEach(b=>b.classList.toggle('selected',b===btn));
      next.disabled = false;
    }));
  }
  function getProducts() {
    const cards = [...document.querySelectorAll('#collectionProducts .product-card')];
    const unique = new Map();
    cards.forEach(card=>{
      const name = card.dataset.name || '';
      if (!unique.has(name)) {
        unique.set(name,{
          name,
          tags:(card.dataset.tags||'').split(/\s+/).filter(Boolean),
          brand:card.querySelector('.product-brand')?.textContent || '',
          price:card.querySelector('.price-line strong')?.textContent || '',
          image:card.querySelector('.product-image img')?.getAttribute('src') || '',
          card
        });
      }
    });
    return [...unique.values()];
  }
  function renderResults() {
    progress.style.width = '100%';
    stepLabel.textContent = 'اكتملت إجاباتك';
    back.disabled = true;
    next.style.display = 'none';
    const wanted = [];
    if (answers.audience && answers.audience !== 'any') wanted.push(answers.audience);
    ['occasion','family','strength'].forEach(k=>{if(answers[k])wanted.push(answers[k])});
    const scored = getProducts().map(p=>({
      ...p,
      score:wanted.reduce((sum,tag)=>sum+(p.tags.includes(tag)?1:0),0)
    })).filter(p=>p.score>0).sort((a,b)=>b.score-a.score);
    const top = scored.slice(0,3);
    content.innerHTML = `
      <div class="quiz-result-intro">
        <div class="result-mark">✦</div>
        <h3>اختيارات تليق بذوقك</h3>
        <p>رشّحنا لك العطور الأقرب لإجاباتك بناءً على تصنيفاتها.</p>
      </div>
      ${top.length ? `<div class="quiz-results">${top.map(p=>`
        <article class="quiz-result-card">
          <img src="${p.image}" alt="${p.name}">
          <div class="quiz-result-info">
            <small>${p.brand}</small><strong>${p.name}</strong><span>${p.price}</span>
            <a href="#collection" class="quiz-view-product">عرض العطر ←</a>
          </div>
        </article>`).join('')}</div>` : `<div class="quiz-no-results">لسه مفيش عطور مطابقة لكل اختياراتك. جرّب تغيير إجابة أو ارجع للتشكيلة وشوف كل العطور المتاحة.</div>`}
      <button class="quiz-restart" id="quizRestart">إعادة الاختبار</button>`;
    content.querySelectorAll('.quiz-view-product').forEach(a=>a.addEventListener('click',close));
    document.getElementById('quizRestart').addEventListener('click',()=>{
      step=0;answers={};resultMode=false;next.style.display='';render();
    });
  }
  next.addEventListener('click',()=>{
    if (!answers[questions[step].key]) return;
    if (step < questions.length-1) { step++; render(); }
    else { resultMode=true; renderResults(); }
  });
  back.addEventListener('click',()=>{
    if (resultMode) return;
    if (step>0) { step--; render(); }
  });
  document.getElementById('quizClose').addEventListener('click',close);
  document.getElementById('heroQuizStart').addEventListener('click',open);
  document.querySelectorAll('a[href="#quiz"]').forEach(a=>a.addEventListener('click',e=>{ e.preventDefault(); open(); }));
  overlay.addEventListener('click',e=>{if(e.target===overlay)close()});
  document.addEventListener('keydown',e=>{if(e.key==='Escape'&&overlay.classList.contains('open'))close()});
})();
