# Al-Amin Perfumes — Website Redesign Prototype

Open `index.html` in a modern browser. Internet access is required to load the Google Fonts.

## Included
- Arabic RTL responsive storefront prototype
- Desktop-first layout with mobile adaptation
- Sections: Home, best sellers, perfume discovery, collection, reviews, about, FAQ, contact, footer
- Interactive product filtering, search, cart drawer, FAQ accordion
- Live Arabic font switcher: Noto Naskh Arabic, Amiri, Aref Ruqaa, Noto Kufi Arabic, IBM Plex Sans Arabic

## Important content note
The live GitHub Pages site could not be fetched in this environment. This prototype preserves the section structure and commercial details available in the conversation, but some copy and product data are illustrative placeholders. Replace them with exact existing site copy and verified catalog data before production.

The perfume product image crops are temporary visual references extracted from the previously approved concept mockup. Replace them with the original product photography.

## Files
- `index.html`
- `styles.css`
- `script.js`
- `assets/`


## Perfume finder quiz
The "ابدأ الاختبار" action opens a branded four-question quiz. Recommendations are computed from product tags, not a fixed product mapping.

Add comma-separated tags to each product card using `data-tags`, for example:
`data-tags="men,daily,fresh,moderate"`

Supported tag values in this prototype:
- Audience: `men`, `women`, `unisex`
- Occasion: `daily`, `outing`, `occasion`
- Scent family: `fresh`, `sweet`, `woody`, `floral`
- Intensity: `soft`, `moderate`, `strong`

The matcher ranks products by the number of selected tags they share. In production, store these tags in the product record in D1 and return them from the API; the admin should manage them as selectable tags.


## Latest update: Brand-aligned perfume finder
- Reworked hero with the Al-Amin logo, stronger hierarchy, and clearer calls to action.
- Added a four-question fragrance finder using the supplied reference interaction.
- The quiz asks about recipient, occasion, scent family, and intensity.
- Recommendations are ranked from product `data-tags`; update those tags from the admin product records when connected to the backend.
- Quiz modal follows the Al-Amin navy, ivory, and champagne-gold identity, with responsive mobile behavior.
