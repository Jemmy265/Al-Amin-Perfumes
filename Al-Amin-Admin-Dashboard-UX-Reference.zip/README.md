# Al-Amin Perfumes — Admin Dashboard UX Reference

A mobile-first, Arabic RTL admin dashboard prototype for the Al-Amin Perfumes store.

## Run
Open `index.html` in a browser. Google Fonts are loaded from Google Fonts, so an internet connection is needed for the intended typography.

## Prototype screens
- Overview / dashboard
- Products: search, filter, add, edit, delete, publish/draft status
- Product image upload preview
- Multiple sizes and prices per product
- Manual product ordering with drag-and-drop on desktop and up/down controls on touch devices
- Quiz tags editor for audience, occasion, fragrance family, and intensity
- Homepage content placeholder
- Store settings / future architecture placeholder

## Important
This is a UX and interaction reference only. Product data is fictional sample data, and changes are stored locally in the browser using localStorage. It is not connected to the live store, database, authentication, or API.

Before production, the implementation agent must inspect the actual Al-Amin repository and reuse its real product data, images, logo, slogans, and quiz taxonomy. Do not copy the sample products from this prototype into production.

## Intended future architecture
- Admin frontend: React + TypeScript + Vite (if the existing storefront uses React, share the same design tokens and components where appropriate)
- API: Hono.js on Cloudflare Workers
- Database: Cloudflare D1
- Image storage: Cloudflare R2
- Frontend hosting: Cloudflare Pages
- Authentication: secure owner/admin authentication, server-side authorization, and session handling; never trust frontend-only route guards.

## Suggested API areas
- `GET/POST /api/admin/products`
- `GET/PATCH/DELETE /api/admin/products/:id`
- `PATCH /api/admin/products/reorder`
- `POST /api/admin/uploads` (signed or authenticated upload flow to R2)
- `GET/PATCH /api/admin/quiz-tags`
- `GET/PATCH /api/admin/content`
