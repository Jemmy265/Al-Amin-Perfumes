const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>[...r.querySelectorAll(s)];
const STORAGE='alamin-admin-demo-v1';
const seed=[
{id:1,name:'Sauvage',brand:'DIOR',category:'men',description:'عطر رجالي منعش بحضور قوي.',sizes:[{size:'35 مل',price:1250},{size:'55 مل',price:1750},{size:'110 مل',price:2600}],status:'published',tags:['men','daily','fresh','strong'],image:'',featured:true},
{id:2,name:'Bleu de Chanel',brand:'CHANEL',category:'men',description:'توازن أنيق بين الانتعاش والعمق.',sizes:[{size:'35 مل',price:1300},{size:'55 مل',price:1850}],status:'published',tags:['men','outings','woody','medium'],image:'',featured:true},
{id:3,name:'Acqua di Giò',brand:'ARMANI',category:'men',description:'انتعاش مستوحى من البحر والطبيعة.',sizes:[{size:'35 مل',price:1200},{size:'110 مل',price:2450}],status:'published',tags:['men','daily','fresh','calm'],image:'',featured:false},
{id:4,name:'Oud Wood',brand:'TOM FORD',category:'unisex',description:'طابع خشبي دافئ وأنيق.',sizes:[{size:'35 مل',price:1450},{size:'55 مل',price:2050}],status:'published',tags:['unisex','formal','woody','strong'],image:'',featured:false},
{id:5,name:'Libre',brand:'YVES SAINT LAURENT',category:'women',description:'عطر أنثوي بتوازن بين الزهور والدفء.',sizes:[{size:'35 مل',price:1350},{size:'55 مل',price:1900}],status:'published',tags:['women','outings','floral','medium'],image:'',featured:false},
{id:6,name:'Rose Oud',brand:'AL AMIN',category:'unisex',description:'مزيج الورد والعود بلمسة شرقية.',sizes:[{size:'35 مل',price:1100}],status:'draft',tags:['unisex','formal','floral','woody','medium'],image:'',featured:false}
];
let products=load(), editingId=null, currentImage='', orderDirty=false, toastTimer;
function load(){try{return JSON.parse(localStorage.getItem(STORAGE))||structuredClone(seed)}catch{return structuredClone(seed)}}
function persist(){localStorage.setItem(STORAGE,JSON.stringify(products));updateStats()}
function money(n){return Number(n||0).toLocaleString('en-US')+' ج.م'}
function firstPrice(p){return p.sizes?.length?Math.min(...p.sizes.map(x=>+x.price||0)):0}
function catName(c){return ({men:'رجالي',women:'نسائي',unisex:'للجنسين'})[c]||c}
function thumb(p){return p.image?`<div class="product-thumb"><img src="${p.image}" alt=""></div>`:`<div class="product-thumb">${(p.brand||p.name||'ع').slice(0,1)}</div>`}
function status(p){return `<span class="pill ${p.status}">${p.status==='published'?'منشور':'مسودة'}</span>`}
function updateStats(){
 $('#statProducts').textContent=products.length;$('#statPublished').textContent=products.filter(p=>p.status==='published').length;$('#statDrafts').textContent=products.filter(p=>p.status==='draft').length;$('#navProductCount').textContent=products.length;
}
function toast(msg){const el=$('#toast');el.textContent=msg;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2300)}
function showView(view){
 $$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+view));
 $$('.nav-item').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 $$('.bottom-nav [data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 const names={overview:'نظرة عامة',products:'إدارة العطور',collections:'ترتيب ظهور العطور',quiz:'وسوم اختبار العطر',content:'محتوى الصفحة الرئيسية',settings:'إعدادات المتجر'};
 $('#pageTitle').textContent=names[view];$('#breadcrumb').textContent=view==='overview'?'الرئيسية':'إدارة المتجر';
 if(view==='products')renderProducts();if(view==='collections')renderOrder();if(view==='quiz')renderTags();if(view==='overview')renderRecent();
 window.scrollTo({top:0,behavior:'smooth'});
}
$$('[data-view]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.view)));
$$('[data-goto]').forEach(b=>b.addEventListener('click',()=>showView(b.dataset.goto)));
$('#todayLabel').textContent=new Intl.DateTimeFormat('ar-EG',{weekday:'long',day:'numeric',month:'long'}).format(new Date());
$('#viewStore').addEventListener('click',()=>toast('اربط رابط المتجر الفعلي عند إعداد المشروع.'));
function renderRecent(){
 $('#recentProducts').innerHTML=products.slice(0,4).map(p=>`<div class="mini-product">${thumb(p)}<div><strong>${p.name}</strong><small>${p.brand||'بدون ماركة'} · ${money(firstPrice(p))}</small></div>${status(p)}</div>`).join('');
}
function moveProduct(id,delta){
 const i=products.findIndex(p=>p.id===id),j=i+delta;if(j<0||j>=products.length)return;
 [products[i],products[j]]=[products[j],products[i]];persist();renderProducts();renderOrder();orderDirty=true;$('#orderStatus').textContent='لديك تغييرات غير محفوظة';
}
function actionButtons(p,mobile=false){
 return mobile?`<div class="mobile-card-actions"><button data-action="edit" data-id="${p.id}">تعديل</button><button data-action="up" data-id="${p.id}">↑</button><button data-action="down" data-id="${p.id}">↓</button></div>`:
 `<div class="table-actions"><button class="tiny-btn" data-action="edit" data-id="${p.id}">تعديل</button><button class="tiny-btn danger" data-action="delete" data-id="${p.id}">حذف</button></div>`;
}
function renderProducts(){
 const q=$('#productSearch').value.trim().toLowerCase(),s=$('#statusFilter').value,c=$('#categoryFilter').value;
 const list=products.filter(p=>(!q||(p.name+' '+p.brand).toLowerCase().includes(q))&&(s==='all'||p.status===s)&&(c==='all'||p.category===c));
 $('#productCountLabel').textContent=`${list.length} منتجات`;
 $('#productRows').innerHTML=list.length?list.map(p=>`<tr><td><div class="table-product">${thumb(p)}<div><strong>${p.name}</strong><small>${p.brand||'—'}</small></div></div></td><td>${catName(p.category)}</td><td>${money(firstPrice(p))}</td><td>${status(p)}</td><td><div class="order-arrows"><button class="tiny-btn" data-action="up" data-id="${p.id}" aria-label="تقديم">↑</button><button class="tiny-btn" data-action="down" data-id="${p.id}" aria-label="تأخير">↓</button></div></td><td>${actionButtons(p)}</td></tr>`).join(''):'<tr><td colspan="6"><div class="empty-state">لا توجد منتجات مطابقة للبحث.</div></td></tr>';
 $('#mobileProductList').innerHTML=list.length?list.map(p=>`<article class="mobile-product-card">${thumb(p)}<div><strong>${p.name}</strong><small>${p.brand||'—'} · ${money(firstPrice(p))}</small><div style="margin-top:5px">${status(p)}</div></div>${actionButtons(p,true)}</article>`).join(''):'<div class="empty-state">لا توجد منتجات مطابقة للبحث.</div>';
}
$('#productSearch').addEventListener('input',renderProducts);$('#statusFilter').addEventListener('change',renderProducts);$('#categoryFilter').addEventListener('change',renderProducts);
document.addEventListener('click',e=>{
 const b=e.target.closest('[data-action]');if(!b)return;
 const id=Number(b.dataset.id),action=b.dataset.action,p=products.find(x=>x.id===id);
 if(action==='edit')openModal(p);
 if(action==='up')moveProduct(id,-1);
 if(action==='down')moveProduct(id,1);
 if(action==='delete'&&p&&confirm(`هل تريد حذف عطر "${p.name}"؟`)){products=products.filter(x=>x.id!==id);persist();renderProducts();renderOrder();toast('تم حذف العطر من المعاينة.');}
});
function renderOrder(){
 $('#orderList').innerHTML=products.map((p,i)=>`<div class="order-row" draggable="true" data-order-id="${p.id}"><span class="drag-handle" title="اسحب لتغيير الترتيب">⠿</span><span class="order-number">${i+1}</span>${thumb(p)}<div class="order-meta"><strong>${p.name}</strong><small>${p.brand||'—'} · ${catName(p.category)} · ${money(firstPrice(p))}</small></div>${status(p)}<div class="order-row-actions"><button class="tiny-btn" data-action="up" data-id="${p.id}">↑</button><button class="tiny-btn" data-action="down" data-id="${p.id}">↓</button></div></div>`).join('');
 let dragged=null;
 $$('#orderList .order-row').forEach(row=>{
  row.addEventListener('dragstart',()=>{dragged=row;row.classList.add('dragging')});
  row.addEventListener('dragend',()=>{row.classList.remove('dragging');dragged=null;});
  row.addEventListener('dragover',e=>{e.preventDefault();if(!dragged||dragged===row)return;const r=row.getBoundingClientRect();const after=e.clientY>r.top+r.height/2;row.parentNode.insertBefore(dragged,after?row.nextSibling:row);});
  row.addEventListener('drop',e=>{e.preventDefault();const ids=$$('#orderList .order-row').map(x=>Number(x.dataset.orderId));products.sort((a,b)=>ids.indexOf(a.id)-ids.indexOf(b.id));orderDirty=true;$('#orderStatus').textContent='لديك تغييرات غير محفوظة';renderOrder();});
 });
}
$('#resetOrder').addEventListener('click',()=>{products.sort((a,b)=>a.id-b.id);renderOrder();orderDirty=true;$('#orderStatus').textContent='تمت استعادة ترتيب البداية — احفظ للتأكيد';});
$('#saveOrder').addEventListener('click',()=>{persist();orderDirty=false;$('#orderStatus').textContent='تم حفظ ترتيب العرض في المعاينة';toast('تم حفظ ترتيب المنتجات في هذه المعاينة.')});

const tagGroups=[
{key:'audience',title:'لمن يناسب العطر؟',options:[['men','رجالي'],['women','نسائي'],['unisex','للجنسين']]},
{key:'occasion',title:'مناسب لأي استخدام؟',options:[['daily','يومي وشغل'],['outings','خروجات وسهرات'],['formal','مناسبات']]},
{key:'family',title:'العائلة العطرية',options:[['fresh','فريش ومنعش'],['sweet','حلو وفانيليا'],['woody','خشبي وعود'],['floral','فواكه وورد']]},
{key:'intensity',title:'قوة العطر',options:[['calm','هادئ'],['medium','متوسط'],['strong','قوي وفواح']]}
];
function renderTags(){
 const sel=$('#tagProductSelect'),old=Number(sel.value);
 sel.innerHTML=products.map(p=>`<option value="${p.id}">${p.name}</option>`).join('');
 if(products.some(p=>p.id===old))sel.value=old;
 renderTagEditor();
}
function renderTagEditor(){
 const p=products.find(x=>x.id===Number($('#tagProductSelect').value))||products[0];if(!p){$('#tagEditor').innerHTML='<p class="empty-state">أضف منتجًا أولًا.</p>';return}
 $('#tagEditor').innerHTML=tagGroups.map(g=>`<div class="tag-category"><h4>${g.title}</h4><div class="tag-options">${g.options.map(([key,label])=>`<button class="tag-chip ${p.tags.includes(key)?'selected':''}" data-tag="${key}" data-product="${p.id}">${label}</button>`).join('')}</div></div>`).join('');
 $$('#tagEditor [data-tag]').forEach(b=>b.addEventListener('click',()=>b.classList.toggle('selected')));
}
$('#tagProductSelect').addEventListener('change',renderTagEditor);
$('#saveTags').addEventListener('click',()=>{
 const p=products.find(x=>x.id===Number($('#tagProductSelect').value));if(!p)return;
 p.tags=$$('#tagEditor .tag-chip.selected').map(b=>b.dataset.tag);persist();$('#tagSaveHint').textContent='تم حفظ الوسوم في المعاينة.';toast('تم حفظ وسوم العطر.');
});

function openModal(p=null){
 editingId=p?.id??null;currentImage=p?.image||'';
 $('#modalTitle').textContent=p?'تعديل بيانات العطر':'إضافة عطر جديد';
 $('#pName').value=p?.name||'';$('#pBrand').value=p?.brand||'';$('#pCategory').value=p?.category||'men';$('#pDescription').value=p?.description||'';
 $$('input[name="pStatus"]').forEach(r=>r.checked=r.value===(p?.status||'published'));
 $('#sizeRows').innerHTML='';(p?.sizes?.length?p.sizes:[{size:'35 مل',price:''}]).forEach(x=>addSizeRow(x.size,x.price));
 renderImage();$('#productModal').classList.add('open');document.body.style.overflow='hidden';
}
function closeModal(){$('#productModal').classList.remove('open');document.body.style.overflow='';}
function addSizeRow(size='',price=''){
 const row=document.createElement('div');row.className='size-row';
 row.innerHTML=`<input class="size-value" placeholder="الحجم، مثل 55 مل" value="${String(size).replaceAll('"','&quot;')}"><input class="price-value" type="number" min="0" placeholder="السعر بالجنيه" value="${price}"><button class="remove-size" type="button" aria-label="حذف الحجم">×</button>`;
 row.querySelector('.remove-size').addEventListener('click',()=>{if($('#sizeRows').children.length>1)row.remove();else toast('يجب إضافة حجم واحد على الأقل.')});
 $('#sizeRows').append(row);
}
$('#addSize').addEventListener('click',()=>addSizeRow());
function renderImage(){const box=$('#imagePreview');box.innerHTML=currentImage?`<img src="${currentImage}" alt="معاينة الصورة">`:`<span>＋</span><b>اضغط لإضافة صورة</b><small>يفضل صورة مربعة بخلفية واضحة</small>`}
$('#productImage').addEventListener('change',e=>{
 const f=e.target.files?.[0];if(!f)return;if(!f.type.startsWith('image/')){toast('اختر ملف صورة صالحًا.');return}
 const reader=new FileReader();reader.onload=()=>{currentImage=reader.result;renderImage()};reader.readAsDataURL(f);
});
$('#removeImage').addEventListener('click',()=>{currentImage='';$('#productImage').value='';renderImage()});
$('#closeModal').addEventListener('click',closeModal);$('#cancelModal').addEventListener('click',closeModal);
$('#productModal').addEventListener('click',e=>{if(e.target===$('#productModal'))closeModal()});
$('#productForm').addEventListener('submit',e=>{
 e.preventDefault();
 const sizes=$$('.size-row',$('#sizeRows')).map(r=>({size:$('.size-value',r).value.trim(),rawPrice:$('.price-value',r).value.trim()})).filter(x=>x.size&&x.rawPrice!==''&&Number.isFinite(Number(x.rawPrice))&&Number(x.rawPrice)>0).map(x=>({size:x.size,price:Number(x.rawPrice)}));
 if(!sizes.length){toast('أضف حجمًا وسعرًا واحدًا على الأقل.');return}
 const item={id:editingId??Date.now(),name:$('#pName').value.trim(),brand:$('#pBrand').value.trim(),category:$('#pCategory').value,description:$('#pDescription').value.trim(),sizes,status:$('input[name="pStatus"]:checked').value,image:currentImage,tags:products.find(p=>p.id===editingId)?.tags||[],featured:false};
 if(editingId){const i=products.findIndex(p=>p.id===editingId);products[i]=item;toast('تم تحديث بيانات العطر.')}else{products.unshift(item);toast('تمت إضافة العطر إلى بداية القائمة.')}
 persist();closeModal();renderProducts();renderOrder();renderRecent();showView('products');
});
$('#addProduct').addEventListener('click',()=>openModal());$('#quickAdd').addEventListener('click',()=>openModal());$('#shortcutAdd').addEventListener('click',()=>openModal());$('#bottomAdd').addEventListener('click',()=>openModal());
renderRecent();renderProducts();renderOrder();updateStats();
